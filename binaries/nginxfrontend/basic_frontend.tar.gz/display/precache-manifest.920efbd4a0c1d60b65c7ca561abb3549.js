self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "518a24a5084f163edc25a7b9128e2970",
    "url": "/display/index.html"
  },
  {
    "revision": "e85126c684fd2338c441",
    "url": "/display/static/css/2.c8e6cc25.chunk.css"
  },
  {
    "revision": "9ffc2b78a3519dd5e1c3",
    "url": "/display/static/css/main.4187bb37.chunk.css"
  },
  {
    "revision": "e85126c684fd2338c441",
    "url": "/display/static/js/2.17ac87a3.chunk.js"
  },
  {
    "revision": "71e9e4dedda4f381ea56e80067d4fca8",
    "url": "/display/static/js/2.17ac87a3.chunk.js.LICENSE.txt"
  },
  {
    "revision": "9ffc2b78a3519dd5e1c3",
    "url": "/display/static/js/main.e29663b4.chunk.js"
  },
  {
    "revision": "8c9bec91d88e0de2d1f8",
    "url": "/display/static/js/runtime-main.84e4f22f.js"
  }
]);