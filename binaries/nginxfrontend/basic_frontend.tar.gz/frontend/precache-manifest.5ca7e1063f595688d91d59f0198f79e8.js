self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "5ca1b0d345a138b97e3b1039220ad708",
    "url": "/frontend/index.html"
  },
  {
    "revision": "f7b64ff79b77c432e1e6",
    "url": "/frontend/static/css/2.1b53b9c3.chunk.css"
  },
  {
    "revision": "d11217e972bd3044b954",
    "url": "/frontend/static/css/main.bff07a6f.chunk.css"
  },
  {
    "revision": "f7b64ff79b77c432e1e6",
    "url": "/frontend/static/js/2.0fc10c60.chunk.js"
  },
  {
    "revision": "1b9ded37f7e2af1e3438fe0c928a348b",
    "url": "/frontend/static/js/2.0fc10c60.chunk.js.LICENSE.txt"
  },
  {
    "revision": "d11217e972bd3044b954",
    "url": "/frontend/static/js/main.35bcc33f.chunk.js"
  },
  {
    "revision": "747c638a0ed8091beb0a",
    "url": "/frontend/static/js/runtime-main.12e52466.js"
  }
]);