self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "bdfe5dfa7f8e4ddbaf27f07860ad8d82",
    "url": "/frontend/index.html"
  },
  {
    "revision": "d6e2c11baa2dc0cd1b12",
    "url": "/frontend/static/css/2.1b53b9c3.chunk.css"
  },
  {
    "revision": "d11217e972bd3044b954",
    "url": "/frontend/static/css/main.bff07a6f.chunk.css"
  },
  {
    "revision": "d6e2c11baa2dc0cd1b12",
    "url": "/frontend/static/js/2.907cfced.chunk.js"
  },
  {
    "revision": "1b9ded37f7e2af1e3438fe0c928a348b",
    "url": "/frontend/static/js/2.907cfced.chunk.js.LICENSE.txt"
  },
  {
    "revision": "d11217e972bd3044b954",
    "url": "/frontend/static/js/main.35bcc33f.chunk.js"
  },
  {
    "revision": "747c638a0ed8091beb0a",
    "url": "/frontend/static/js/runtime-main.12e52466.js"
  }
]);