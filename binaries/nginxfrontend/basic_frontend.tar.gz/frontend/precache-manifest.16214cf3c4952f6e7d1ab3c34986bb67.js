self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "57e4adb0ca0a40cdc0e68f2a3ea750a5",
    "url": "/frontend/index.html"
  },
  {
    "revision": "5d8c8473913a1f4195ce",
    "url": "/frontend/static/css/2.1b53b9c3.chunk.css"
  },
  {
    "revision": "24e78da8c254593ed1ad",
    "url": "/frontend/static/css/main.a05544c4.chunk.css"
  },
  {
    "revision": "5d8c8473913a1f4195ce",
    "url": "/frontend/static/js/2.62ac8589.chunk.js"
  },
  {
    "revision": "1b9ded37f7e2af1e3438fe0c928a348b",
    "url": "/frontend/static/js/2.62ac8589.chunk.js.LICENSE.txt"
  },
  {
    "revision": "24e78da8c254593ed1ad",
    "url": "/frontend/static/js/main.b6617ac0.chunk.js"
  },
  {
    "revision": "747c638a0ed8091beb0a",
    "url": "/frontend/static/js/runtime-main.12e52466.js"
  }
]);