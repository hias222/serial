self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "5300662c4b9a273e6c8c989c15a70da5",
    "url": "/frontend/index.html"
  },
  {
    "revision": "a4645ee3b6a1634ee497",
    "url": "/frontend/static/css/2.1b53b9c3.chunk.css"
  },
  {
    "revision": "d11217e972bd3044b954",
    "url": "/frontend/static/css/main.bff07a6f.chunk.css"
  },
  {
    "revision": "a4645ee3b6a1634ee497",
    "url": "/frontend/static/js/2.0ed24ac0.chunk.js"
  },
  {
    "revision": "1b9ded37f7e2af1e3438fe0c928a348b",
    "url": "/frontend/static/js/2.0ed24ac0.chunk.js.LICENSE.txt"
  },
  {
    "revision": "d11217e972bd3044b954",
    "url": "/frontend/static/js/main.35bcc33f.chunk.js"
  },
  {
    "revision": "747c638a0ed8091beb0a",
    "url": "/frontend/static/js/runtime-main.12e52466.js"
  }
]);