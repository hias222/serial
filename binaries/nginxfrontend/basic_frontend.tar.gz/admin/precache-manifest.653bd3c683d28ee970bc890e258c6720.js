self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "1b5a29b59ff999e83aa57109ae030d91",
    "url": "/admin/index.html"
  },
  {
    "revision": "075186d9d805b9cee4a6",
    "url": "/admin/static/css/main.0185252a.chunk.css"
  },
  {
    "revision": "4ee4a5d5e9e8048c098b",
    "url": "/admin/static/js/2.701e1b38.chunk.js"
  },
  {
    "revision": "89a1b2dcd30c03705b2bceeb141b76b6",
    "url": "/admin/static/js/2.701e1b38.chunk.js.LICENSE.txt"
  },
  {
    "revision": "075186d9d805b9cee4a6",
    "url": "/admin/static/js/main.8d1857c6.chunk.js"
  },
  {
    "revision": "9e907309681cf91dd0a8",
    "url": "/admin/static/js/runtime-main.e2d1bdb9.js"
  }
]);