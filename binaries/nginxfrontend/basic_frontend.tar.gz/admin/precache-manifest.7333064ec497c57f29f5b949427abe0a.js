self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "43c42d178f7a35f45261799802b08998",
    "url": "/admin/index.html"
  },
  {
    "revision": "eeef65434ed34fc5819b",
    "url": "/admin/static/css/main.b76435c0.chunk.css"
  },
  {
    "revision": "266bd3def60237ac93fe",
    "url": "/admin/static/js/2.1da7a24f.chunk.js"
  },
  {
    "revision": "6397acf4c5cafcd591a770ce33fc3e2f",
    "url": "/admin/static/js/2.1da7a24f.chunk.js.LICENSE.txt"
  },
  {
    "revision": "eeef65434ed34fc5819b",
    "url": "/admin/static/js/main.ef4767b3.chunk.js"
  },
  {
    "revision": "9e907309681cf91dd0a8",
    "url": "/admin/static/js/runtime-main.e2d1bdb9.js"
  }
]);