self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "d52818b715dbf53bf540048140b84610",
    "url": "/admin/index.html"
  },
  {
    "revision": "c40d3b396b3f6366ad48",
    "url": "/admin/static/css/main.0185252a.chunk.css"
  },
  {
    "revision": "b5ba47e079c92abb853b",
    "url": "/admin/static/js/2.bc7235d9.chunk.js"
  },
  {
    "revision": "89a1b2dcd30c03705b2bceeb141b76b6",
    "url": "/admin/static/js/2.bc7235d9.chunk.js.LICENSE.txt"
  },
  {
    "revision": "c40d3b396b3f6366ad48",
    "url": "/admin/static/js/main.6a78cc7b.chunk.js"
  },
  {
    "revision": "9e907309681cf91dd0a8",
    "url": "/admin/static/js/runtime-main.e2d1bdb9.js"
  }
]);