self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "10b09127fec611cfc492533ab64e3188",
    "url": "/admin/index.html"
  },
  {
    "revision": "18482d4af1eb7b072903",
    "url": "/admin/static/css/main.0185252a.chunk.css"
  },
  {
    "revision": "7166275303ceacab5c85",
    "url": "/admin/static/js/2.e2a26840.chunk.js"
  },
  {
    "revision": "89a1b2dcd30c03705b2bceeb141b76b6",
    "url": "/admin/static/js/2.e2a26840.chunk.js.LICENSE.txt"
  },
  {
    "revision": "18482d4af1eb7b072903",
    "url": "/admin/static/js/main.e8ce1742.chunk.js"
  },
  {
    "revision": "9e907309681cf91dd0a8",
    "url": "/admin/static/js/runtime-main.e2d1bdb9.js"
  }
]);