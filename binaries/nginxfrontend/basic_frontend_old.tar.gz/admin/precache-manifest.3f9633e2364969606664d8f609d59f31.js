self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "6104ed9cfc2e7bdb5bce41fa46fecf57",
    "url": "/admin/index.html"
  },
  {
    "revision": "05cdb89f3c824f4ee3f4",
    "url": "/admin/static/css/main.0185252a.chunk.css"
  },
  {
    "revision": "1da1cd2dec4f424c9c78",
    "url": "/admin/static/js/2.7b80dfd5.chunk.js"
  },
  {
    "revision": "6397acf4c5cafcd591a770ce33fc3e2f",
    "url": "/admin/static/js/2.7b80dfd5.chunk.js.LICENSE.txt"
  },
  {
    "revision": "05cdb89f3c824f4ee3f4",
    "url": "/admin/static/js/main.529387d6.chunk.js"
  },
  {
    "revision": "9e907309681cf91dd0a8",
    "url": "/admin/static/js/runtime-main.e2d1bdb9.js"
  }
]);