self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "f0db7277a637eb6017d227a37d1c810d",
    "url": "/admin/index.html"
  },
  {
    "revision": "03bfc3382d0210d8e7f9",
    "url": "/admin/static/css/main.0185252a.chunk.css"
  },
  {
    "revision": "95257dfb13a5a05f00fa",
    "url": "/admin/static/js/2.d41a9668.chunk.js"
  },
  {
    "revision": "89a1b2dcd30c03705b2bceeb141b76b6",
    "url": "/admin/static/js/2.d41a9668.chunk.js.LICENSE.txt"
  },
  {
    "revision": "03bfc3382d0210d8e7f9",
    "url": "/admin/static/js/main.d2f279f3.chunk.js"
  },
  {
    "revision": "9e907309681cf91dd0a8",
    "url": "/admin/static/js/runtime-main.e2d1bdb9.js"
  }
]);