self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "4ae28f586e1c1372ca845b28b48002f4",
    "url": "/admin/index.html"
  },
  {
    "revision": "5d71ae165417c4b0af92",
    "url": "/admin/static/css/main.0185252a.chunk.css"
  },
  {
    "revision": "1da1cd2dec4f424c9c78",
    "url": "/admin/static/js/2.7b80dfd5.chunk.js"
  },
  {
    "revision": "6397acf4c5cafcd591a770ce33fc3e2f",
    "url": "/admin/static/js/2.7b80dfd5.chunk.js.LICENSE.txt"
  },
  {
    "revision": "5d71ae165417c4b0af92",
    "url": "/admin/static/js/main.e8c294cf.chunk.js"
  },
  {
    "revision": "9e907309681cf91dd0a8",
    "url": "/admin/static/js/runtime-main.e2d1bdb9.js"
  }
]);