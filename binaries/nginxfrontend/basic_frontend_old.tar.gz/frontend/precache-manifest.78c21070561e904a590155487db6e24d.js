self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "fc328c05f4107adfb92aeaabc669126b",
    "url": "/frontend/index.html"
  },
  {
    "revision": "87c6c9063352589248b5",
    "url": "/frontend/static/css/2.c8e6cc25.chunk.css"
  },
  {
    "revision": "22fc1ad92a40fb3a7fb9",
    "url": "/frontend/static/css/main.691dc99d.chunk.css"
  },
  {
    "revision": "87c6c9063352589248b5",
    "url": "/frontend/static/js/2.ee8163ce.chunk.js"
  },
  {
    "revision": "69c5fecb15033eb3fd434d9d1055fed1",
    "url": "/frontend/static/js/2.ee8163ce.chunk.js.LICENSE.txt"
  },
  {
    "revision": "22fc1ad92a40fb3a7fb9",
    "url": "/frontend/static/js/main.c5e2cc78.chunk.js"
  },
  {
    "revision": "76fdbb2bd4098d6022fd",
    "url": "/frontend/static/js/runtime-main.2489ba79.js"
  }
]);