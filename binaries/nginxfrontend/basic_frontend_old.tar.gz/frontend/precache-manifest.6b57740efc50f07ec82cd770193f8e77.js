self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "0d786056bdb17ff3355f8c6222dcc90c",
    "url": "/frontend/index.html"
  },
  {
    "revision": "b6b2437f8cda93c55f03",
    "url": "/frontend/static/css/2.c8e6cc25.chunk.css"
  },
  {
    "revision": "67910d49a8c8e6f89525",
    "url": "/frontend/static/css/main.691dc99d.chunk.css"
  },
  {
    "revision": "b6b2437f8cda93c55f03",
    "url": "/frontend/static/js/2.7ba14f41.chunk.js"
  },
  {
    "revision": "69c5fecb15033eb3fd434d9d1055fed1",
    "url": "/frontend/static/js/2.7ba14f41.chunk.js.LICENSE.txt"
  },
  {
    "revision": "67910d49a8c8e6f89525",
    "url": "/frontend/static/js/main.6b50b4b9.chunk.js"
  },
  {
    "revision": "76fdbb2bd4098d6022fd",
    "url": "/frontend/static/js/runtime-main.2489ba79.js"
  }
]);